#include "coreWatch.h"
#include "kbhit.h"

/*fsm_trans_t fsmTransCoreWatch[] = {
 { START, CompruebaSetupDone, STAND_BY, Start }, { STAND_BY,
 CompruebaTimeActualizado, STAND_BY, ShowTime }, { STAND_BY,
 CompruebaReset, STAND_BY, Reset }, { STAND_BY,
 CompruebaSetCancelNewTime, SET_TIME, PrepareSetNewTime }, {
 SET_TIME, CompruebaDigitoPulsado, SET_TIME, ProcesaDigitoTime },
 { SET_TIME, CompruebaSetCancelNewTime, STAND_BY, CancelSetNewTime }, {
 SET_TIME, CompruebaNewTimeIsReady, STAND_BY, SetNewTime }, { -1,
 NULL, -1, NULL }, };*/

fsm_trans_t fsmTransCoreWatch[] = {
		{ START, CompruebaSetupDone, STAND_BY, Start }, { STAND_BY,
				CompruebaTimeActualizado, STAND_BY, ShowTime }, { STAND_BY,
				CompruebaReset, STAND_BY, Reset }, { STAND_BY,
				CompruebaSetCancelNewTime, SET_TIME, PrepareSetNewTime },
		{ SET_TIME, CompruebaSetCancelNewTime, STAND_BY, CancelSetNewTime }, {
				SET_TIME, CompruebaNewTimeIsReady, STAND_BY, SetNewTime }, {
				SET_TIME, CompruebaDigitoPulsado, SET_TIME, ProcesaDigitoTime },
		{ -1, NULL, -1, NULL }, };

TipoCoreWatch g_corewatch;
static int g_flagsCoreWatch;

volatile int flags = 0;

/////////////
//VERSION 3//
/////////////

const int arrayFilas[4] = { GPIO_KEYBOARD_ROW_1, GPIO_KEYBOARD_ROW_2,
		GPIO_KEYBOARD_ROW_3, GPIO_KEYBOARD_ROW_4 };
const int arrayColumnas[4] = { GPIO_KEYBOARD_COL_1, GPIO_KEYBOARD_COL_2,
		GPIO_KEYBOARD_COL_3, GPIO_KEYBOARD_COL_4 };

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
// Wait until next_activation (absolute time)
// Necesita de la función "delay" de WiringPi.
void DelayUntil(unsigned int next) {
	unsigned int now = millis();
	if (next > now) {
		delay(next - now);
	}
}

//------------------------------------------------------
// MAIN
//fflush(stdout) vacia para forzar que se haga lo que hemos pedido
//------------------------------------------------------

#if VERSION == 2

PI_THREAD(ThreadExploraTecladoPC) {

	int teclaPulsada;
	while (1) {
		delay(10);

		if (kbhit()) { //Est� pulsada una tecla
			teclaPulsada = kbread();
			if (teclaPulsada == TECLA_RESET) {
				piLock(SYSTEM_KEY);
				g_flagsCoreWatch |= FLAG_RESET; //Activa flag
				piUnlock(SYSTEM_KEY);
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Has pulsado tecla F \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else if (teclaPulsada == TECLA_SET_CANCEL_TIME) {
				piLock(SYSTEM_KEY);
				g_flagsCoreWatch |= FLAG_SET_CANCEL_NEW_TIME; //Activa flag
				piUnlock(SYSTEM_KEY);
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Has pulsado tecla E \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else if (EsNumero(teclaPulsada)) {
				g_corewatch.digitoPulsado = teclaPulsada; //Nuestra tecla pulsda es el digito pulsado del reloj
				piLock(SYSTEM_KEY);
				g_flagsCoreWatch |= FLAG_DIGITO_PULSADO;//Activa flag
				piUnlock(SYSTEM_KEY);
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("La Tecla Pulsada es un Numero, %d \n", teclaPulsada);//Informa a usuario de salida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else if (teclaPulsada == TECLA_EXIT) {
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Se va a salir del sistema \n"); //Informa a usuario de salida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
				exit(0);//Sale del sistema
			} else if ((teclaPulsada != '\n') && (teclaPulsada != '\r') && (teclaPulsada != 0xA)) {
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Error: Tecla desconocida \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else {

			}
		}
	}

	//pag 84 AP�NDICE A
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Hebra creada correctamente \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
}
#endif

#if VERSION >= 2

int ConfiguraInicializaSistema(TipoCoreWatch *p_sistema) {
	g_flagsCoreWatch = 0;

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	int resultInicializarReloj = ConfiguraInicializaReloj(&(p_sistema->reloj));
	//Recoge el resultado de la inicializacion
	if (resultInicializarReloj != 0) {
		return 1;
	}

	memcpy(p_sistema->teclado.filas, arrayFilas, sizeof(arrayFilas));
	memcpy(p_sistema->teclado.columnas, arrayColumnas, sizeof(arrayColumnas));

	int IniDriver;
	IniDriver = wiringPiSetupGpio(); ///////////Preguntar al profe qu� comparamos para ver si es correcta la inicializaci�n

	if (IniDriver != 0) {
		return 1;
	}

	ConfiguraInicializaTeclado(&(p_sistema->teclado));

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Se ha inicializado correctamente el driver\n"); //Informa a usuario de qyue se ha inicializado correctamente el driver
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	/////////////////////////////////////////////////////////////////////////////////////////////////////////

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Las teclas que puede pulsar son: \n Tecla E: Tecla set cancel time \n Tecla F: Tecla para reiniciar \n Tecla B: Tecla para salir \n ");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);


#if VERSION == 2
	int resultInicializarThread = piThreadCreate(ThreadExploraTecladoPC); //Repasar como lanzar un thread con piThreadCreate, cap 4

	//Recoge resultado de la llamada
	if (resultInicializarThread != 0) {
		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("Hebra no creada correctamente \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);
		return 1;
	}
#endif

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch |= FLAG_SETUP_DONE; //Activa el flag
	piUnlock(SYSTEM_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf(" \n Configuracion completada \n ");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	return 0;
}

int EsNumero(char value) {
	//if (value < 48 || value > 57)
	//if( value < 0x30 || value > 0x39)
	if (value < '0' || value > '9') {
		return 0;
	} else {
		return 1;
	}
}

int CompruebaDigitoPulsado(fsm_t* p_this) {
	int pFlag;
	piLock(SYSTEM_KEY);
	pFlag = g_flagsCoreWatch & FLAG_DIGITO_PULSADO;	//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);
	return pFlag;

}

int CompruebaNewTimeIsReady(fsm_t* p_this) {
	int pFlag;
	////////////////////////////////////////////////////////////////////////////////////
	//Comprobar si se leen los d�gitos de la hora
	piLock(SYSTEM_KEY);
	pFlag = g_flagsCoreWatch & FLAG_NEW_TIME_IS_READY;
	piUnlock(SYSTEM_KEY);
	return pFlag;
}

int CompruebaReset(fsm_t* p_this) {
	int pFlag;

	piLock(SYSTEM_KEY);
	//Cuando sea pulsado 'F' se activa el flag
	pFlag = g_flagsCoreWatch & FLAG_RESET;//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);

	return pFlag;
}

int CompruebaSetCancelNewTime(fsm_t* p_this) {
	int pFlag;

	piLock(SYSTEM_KEY);
	//La misma tecla 'E' sirve tanto para indicar que quiero cambio hora o cancelar operacion
	pFlag = g_flagsCoreWatch & FLAG_SET_CANCEL_NEW_TIME;//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);

	return pFlag;
}

int CompruebaSetupDone(fsm_t* p_this) {
	int pFlag;
	piLock(SYSTEM_KEY);
	//El flag se activa al finalizar config e inic del sistema
	pFlag = g_flagsCoreWatch & FLAG_SETUP_DONE;	//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);
	return pFlag;
}

int CompruebaTeclaPulsada(fsm_t* p_this) {
	//VERSION 3
	return 0;
}

int CompruebaTimeActualizado(fsm_t* p_this) {
	int pFlag;
	TipoRelojShared var = GetRelojSharedVar();
	//El flag se activa al finalizar config e inic del sistema
	pFlag = var.flags & FLAG_TIME_ACTUALIZADO;//Comprueba si se ha activado el flag

	return pFlag;
}

void Start(fsm_t* p_this) {

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[STAND-BY] start\n");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SETUP_DONE);	//Limpia el flag que activa ConfiguraInicializaSistema
	piUnlock(SYSTEM_KEY);

}

void ShowTime(fsm_t* p_this) {
	//////////////////////////////////////////////////////////////////////////////
	//Preguntar al profe

	/*piLock(STD_IO_LCD_BUFFER_KEY);
	 printf("[STAND-BY] Showtime\n");
	 fflush(stdout);
	 piUnlock(STD_IO_LCD_BUFFER_KEY);*/
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	/////////////////////////////////////////////////////////////////////////
	TipoRelojShared var = GetRelojSharedVar();//Recoge la estructura del reloj del sistema
	//piLock(RELOJ_KEY);
	var.flags &= (~FLAG_TIME_ACTUALIZADO);	//Limpia el flag
	//piUnlock(RELOJ_KEY);
	SetRelojSharedVar(var);

#if VERSION == 2
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Son las %d:%d:%d del %d/%d/%d\n", p_sistema->reloj.hora.hh,
			p_sistema->reloj.hora.mm, p_sistema->reloj.hora.ss,
			p_sistema->reloj.calendario.dd, p_sistema->reloj.calendario.MM,
			p_sistema->reloj.calendario.yyyy);
	fflush(stdout); //PREGUNTAR EN CLASE
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif
}

void CancelSetNewTime(fsm_t* p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);
	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SET_CANCEL_NEW_TIME); //Limpia el flag que nos ha hecho llegar hasta aqu�
	piUnlock(SYSTEM_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_TIME] Operacion cancelada \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
}

void PrepareSetNewTime(fsm_t* p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);
	int formatoHora = p_sistema->reloj.hora.formato;

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO);	//Limpia el flag PARA ASEGURAR QUE NO EST� ACTIVO POR HABER
	//PRESIONADO ALGBG�N N�MERO PREVIAMENTE
	piUnlock(SYSTEM_KEY);

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SET_CANCEL_NEW_TIME); //Limpia el flag que nos ha hecho llegar hasta aqu�
	piUnlock(SYSTEM_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_TIME] Introduzca la nueva hora en formato 0-%d \n",
			formatoHora); //Informa a usuario de qyue ha pulsado una tecla no v�lida
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
}

/*void ProcesaDigitoTime(fsm_t* p_this) {
 TipoCoreWatch *p_sistema = (TipoCoreWatch*)(p_this->user_data);
 //No pueden ser locales y static p�rque si no CancelSetNewTime no puede limpiar valores temporales ni acceder a ellos
 //por eso est�n en estructuras del sistema
 int tempTimeAux = p_sistema->tempTime;
 int digGuardAux = p_sistema->digitosGuardados;
 //int ultimoDigito = p_sistema->digitoPulsado;
 int ultimoDigito = p_sistema->digitoPulsado - 48;

 piLock(SYSTEM_KEY);
 g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO); //Limpia el flag que nos ha hecho llegar hasta aqu�
 piUnlock(SYSTEM_KEY);


 if(digGuardAux == 0){
 if(p_sistema->reloj.hora.formato == 12){
 ultimoDigito = MIN(1, ultimoDigito);
 }else{
 ultimoDigito = MIN(2, ultimoDigito);
 }
 tempTimeAux = tempTimeAux*10 + ultimoDigito;
 digGuardAux++;
 }else if(digGuardAux == 1){
 if(p_sistema->reloj.hora.formato == 12){
 if(tempTimeAux == 0){
 ultimoDigito = MAX(1, ultimoDigito);
 tempTimeAux = tempTimeAux*10 + ultimoDigito;
 }else{
 ultimoDigito = MIN(2, ultimoDigito);
 tempTimeAux = tempTimeAux*10 + ultimoDigito;
 }
 }else{
 if(tempTimeAux == 2){
 ultimoDigito = MIN(3, ultimoDigito);
 tempTimeAux = tempTimeAux*10 + ultimoDigito;
 }else{
 tempTimeAux = tempTimeAux*10 + ultimoDigito;
 }
 }
 digGuardAux++;
 }else if(digGuardAux == 2){
 tempTimeAux = tempTimeAux*10 + MIN(5, ultimoDigito);
 digGuardAux++;
 }else{
 tempTimeAux = tempTimeAux*10 + ultimoDigito;

 piLock(SYSTEM_KEY);
 g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO); //Limpia el flag que nos ha hecho llegar hasta aqu�
 piUnlock(SYSTEM_KEY);

 piLock(SYSTEM_KEY);
 g_flagsCoreWatch |= FLAG_NEW_TIME_IS_READY;//Activa flag
 piLock(SYSTEM_KEY);
 }

 if (digGuardAux < 3){
 if(tempTimeAux > 2359){
 tempTimeAux %= 10000;
 tempTimeAux = 100* MIN((int)(tempTimeAux/100), 23) + MIN(tempTimeAux%100, 59);
 }
 }
 piLock(STD_IO_LCD_BUFFER_KEY);
 printf("[SET_TIME] Nueva hora temporal %d \n", tempTimeAux); //Informa a usuario de qyue ha pulsado una tecla no v�lida
 fflush(stdout);
 piUnlock(STD_IO_LCD_BUFFER_KEY);

 p_sistema->tempTime = tempTimeAux;
 p_sistema->digitosGuardados = digGuardAux;
 }
 */
void ProcesaDigitoTime(fsm_t* p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	int auxDigitos = p_sistema->digitosGuardados;
	int auxTemp = p_sistema->tempTime;

#if VERSION == 2
	int ultimoDigito = p_sistema->digitoPulsado - 48; // - 48? por ASCII
#endif

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO); // Baja la flag (En enunciado, "limpiar")
	piUnlock(SYSTEM_KEY);

	if (auxDigitos == 0) {
		if (p_sistema->reloj.hora.formato == 12) {
			ultimoDigito = MIN(1, ultimoDigito);
		} else {
			ultimoDigito = MIN(2, ultimoDigito);

		}

		auxTemp = auxTemp * 10 + ultimoDigito;
		auxDigitos = auxDigitos + 1;
	}

	else if (auxDigitos == 1) {
		if (p_sistema->reloj.hora.formato == 12) {
			if (auxTemp == 0) {
				ultimoDigito = MAX(1, ultimoDigito);
			} else { // if(p_sistema->tempTime != 0)
				ultimoDigito = MIN(2, ultimoDigito);
			}
			auxTemp = auxTemp * 10 + ultimoDigito;
			auxDigitos = auxDigitos + 1;
		}

		else { // if(p_sistema->reloj.hora.formato != 12)
			if (auxTemp == 2) {
				ultimoDigito = MIN(3, ultimoDigito);
				auxTemp = auxTemp * 10 + ultimoDigito;
			} else { // if (p_sistema->tempTime != 2)
				auxTemp = auxTemp * 10 + ultimoDigito;
			}
			auxDigitos = auxDigitos + 1;
		}
	}

	else if (auxDigitos == 2) {
		auxTemp = auxTemp * 10 + MIN(5, ultimoDigito);
		auxDigitos = auxDigitos + 1;
	} else if (auxDigitos == 3) {
		auxTemp = auxTemp * 10 + ultimoDigito;

		piLock(SYSTEM_KEY);
		g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO); // Limpio la flag "Por seguridad" -- BAJAR
		piUnlock(SYSTEM_KEY);
		piLock(SYSTEM_KEY);
		g_flagsCoreWatch |= FLAG_NEW_TIME_IS_READY; // Activo FLAG_NEW_TIME_IS_READY -- SUBIR
		piUnlock(SYSTEM_KEY);
	}
	if (auxDigitos < 3) {
		if (auxTemp > 2359) {
			auxTemp %= 10000;
			auxTemp = 100 * MIN((int )(auxTemp / 100), 23)
					+ MIN(auxTemp % 100, 59);
		}
	}
	p_sistema->tempTime = auxTemp;
	p_sistema->digitosGuardados = auxDigitos;

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_TIME]: Nueva hora temporal %d\n", p_sistema->tempTime); // Informo al usuario del valor de tempTime
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
}

void ProcesaTeclaPulsada(fsm_t* p_this) {
	//Anologo a Thread VERSION 2
}

void Reset(fsm_t* p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);
	ResetReloj(&(p_sistema->reloj));

	/*piLock(STD_IO_LCD_BUFFER_KEY);
	 printf("[STAND-BY] Reset\n");
	 fflush(stdout);
	 piUnlock(STD_IO_LCD_BUFFER_KEY);
	 */
	piLock(RELOJ_KEY);
	g_flagsCoreWatch &= (~FLAG_RESET); //Limpia el flag que nos ha hecho llegar hasta aqui
	piUnlock(RELOJ_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[RESET] Hora reiniciada \n");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
}

void SetNewTime(fsm_t* p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_NEW_TIME_IS_READY);//Limpia el flag que nos ha hecho llegar hasta aqu�
	piUnlock(SYSTEM_KEY);

	SetHora(p_sistema->tempTime, (&(p_sistema->reloj.hora)));
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_NEW_TIME] La hora usada en SetHora es %d \n",
			p_sistema->tempTime);
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;
}

#endif

int main() {
	unsigned int next;
	//TipoReloj relojPrueba; //Despues va ConfiguraInicializaSesion

	fsm_t* fsmReloj = fsm_new(WAIT_TIC, g_fsmTransReloj, &(g_corewatch.reloj));
	fsm_t* fsmCoreWatch = fsm_new(START, fsmTransCoreWatch, &(g_corewatch));

#if VERSION <= 1
	//TipoReloj relojPrueba; //Despues va ConfiguraInicializaSesion
	ConfiguraInicializaReloj(&relojPrueba);
	SetHora(2359, &(relojPrueba.hora));

#endif

#if VERSION >= 2
	int resultConfig = ConfiguraInicializaSistema(&g_corewatch);
	//SetHora(2359, &(g_corewatch.reloj.hora));

	if (resultConfig != 0) {
		printf("Error: Se va a salir del sistema \n"); //Informa a usuario de salida
		fflush(stdout);
		exit(0); //Sale del sistema
	}
#endif

	next = millis();
	while (1) {
		fsm_fire(fsmReloj);
		fsm_fire(fsmCoreWatch);
		next += CLK_MS;
		DelayUntil(next);
	}
	tmr_destroy(g_corewatch.reloj.tmrTic);
	fsm_destroy(fsmReloj);
	fsm_destroy(fsmCoreWatch);

}
