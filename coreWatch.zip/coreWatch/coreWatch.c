#include "coreWatch.h"
#include "kbhit.h"

/*fsm_trans_t g_fsmTransReloj[] = {{START, CompruebaSetupDone, STAND_BY, Start},
								{STAND_BY, CompruebaTimeActualizado, STAND_BY, ShowTime},
								{STAND_BY, CompruebaReset, STAND_BY, Reset},
								{STAND_BY, CompruebaSetCancelNewTime, SET_TIME, PrepareSetNewTime},
								{SET_TIME, CompruebaDigitoPulsado, SET_TIME, ProcesaDigitoTime},
								{SET_TIME, CompruebaSetCancelNewTime, STAND_BY, CancelSetNewTime},
								{SET_TIME,CompruebaNewTimeIsReady, STAND_BY, SetNewTime},
								{-1, NULL, -1, NULL},};*/


TipoCoreWatch g_corewatch;
static int g_flagsCoreWatch;

//volatile int flags = 0;

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
// Wait until next_activation (absolute time)
// Necesita de la función "delay" de WiringPi.
void DelayUntil(unsigned int next) {
	unsigned int now = millis();
	if (next > now) {
		delay(next - now);
	}
}


//------------------------------------------------------
// MAIN
//fflush(stdout) vacia para forzar que se haga lo que hemos pedido
//------------------------------------------------------
int main() {
	unsigned int next;
	//TipoReloj relojPrueba;//Despues va ConfiguraInicializaSesion

#if VERSION <= 1
	TipoReloj relojPrueba;//Despues va ConfiguraInicializaSesion
	ConfiguraInicializaReloj(&relojPrueba);
	SetHora(2359, &(relojPrueba.hora));

#endif

fsm_t* fsmReloj = fsm_new(WAIT_TIC, g_fsmTransReloj, &(relojPrueba));
	next = millis();
	while (1) {
		fsm_fire(fsmReloj);

		next += CLK_MS;
		DelayUntil(next);
	}
}

#if VERSION >= 2

PI_THREAD(ThreadExploraTecladoPC){

	int teclaPulsada;
	while(1){
		delay(10);

		if(khbit()){//Est� pulsada una tecla
			teclaPulsada = kbread();
		}
		if(teclaPulsada == TECLA_RESET){
			g_flagsCoreWatch.flags |= FLAG_RESET;//Activa flag
		}
	}

	//pag 84 AP�NDICE A

}

int ConfiguraInicializaSistema(TipoCoreWatch *p_sistema){
	g_flagsCoreWatch = 0;

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	int resultInicializarReloj = ConfiguraInicializaReloj(&p_sistema->reloj);
	//Recoge el resultado de la inicializacion
	if (resultInicializarReloj == 0) {
		return 1;
	}

	/*resultInicializarThread = piThreadCreate(ThreadExploraTecladoPC);//Repasar como lanzar un thread con piThreadCreate, cap 4
	//Recoge resultado de la llamada
	if (resultInicializarThread != 0){
		return 2;
	}*/
return 0;


}


#endif
