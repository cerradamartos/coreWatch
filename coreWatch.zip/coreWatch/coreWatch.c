#include "coreWatch.h"
#include "kbhit.h"


fsm_trans_t fsmTransCoreWatch[] = {
		{ START, CompruebaSetupDone, STAND_BY, Start },
		{ STAND_BY, CompruebaTimeActualizado, STAND_BY, ShowTime },
		{ STAND_BY, CompruebaReset, STAND_BY, Reset },
		{ STAND_BY, CompruebaSetCancelNewTime, SET_TIME, PrepareSetNewTime },
		{ SET_TIME, CompruebaSetCancelNewTime, STAND_BY, CancelSetNewTime },
		{ SET_TIME, CompruebaNewTimeIsReady, STAND_BY, SetNewTime },
		{ SET_TIME, CompruebaDigitoPulsado, SET_TIME, ProcesaDigitoTime },
		{ -1, NULL, -1, NULL }, };

fsm_trans_t fsmTransDeteccionComandos[] = {
		{ WAIT_COMMAND, CompruebaTeclaPulsada, WAIT_COMMAND, ProcesaTeclaPulsada },
		{ -1, NULL, -1, NULL },
};

TipoCoreWatch g_corewatch;
static int g_flagsCoreWatch;

volatile int flags = 0;

/////////////
//VERSION 3//
/////////////

//const int arrayFilas[4] = { GPIO_KEYBOARD_ROW_1, GPIO_KEYBOARD_ROW_2,
//GPIO_KEYBOARD_ROW_3, GPIO_KEYBOARD_ROW_4 };
//const int arrayColumnas[4] = { GPIO_KEYBOARD_COL_1, GPIO_KEYBOARD_COL_2,
//GPIO_KEYBOARD_COL_3, GPIO_KEYBOARD_COL_4 };

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
// Wait until next_activation (absolute time)
// Necesita de la función "delay" de WiringPi.
void DelayUntil(unsigned int next) {
	unsigned int now = millis();
	if (next > now) {
		delay(next - now);
	}
}

//------------------------------------------------------
// MAIN
//fflush(stdout) vacia para forzar que se haga lo que hemos pedido
//------------------------------------------------------

#if VERSION == 2

PI_THREAD(ThreadExploraTecladoPC) {

	int teclaPulsada;
	while (1) {
		delay(10);

		if (kbhit()) { //Est� pulsada una tecla
			teclaPulsada = kbread();
			if (teclaPulsada == TECLA_RESET) {
				piLock(SYSTEM_KEY);
				g_flagsCoreWatch |= FLAG_RESET; //Activa flag
				piUnlock(SYSTEM_KEY);
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Has pulsado tecla F \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else if (teclaPulsada == TECLA_SET_CANCEL_TIME) {
				piLock(SYSTEM_KEY);
				g_flagsCoreWatch |= FLAG_SET_CANCEL_NEW_TIME; //Activa flag
				piUnlock(SYSTEM_KEY);
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Has pulsado tecla E \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else if (EsNumero(teclaPulsada)) {
				g_corewatch.digitoPulsado = teclaPulsada; //Nuestra tecla pulsda es el digito pulsado del reloj
				piLock(SYSTEM_KEY);
				g_flagsCoreWatch |= FLAG_DIGITO_PULSADO;//Activa flag
				piUnlock(SYSTEM_KEY);
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("La Tecla Pulsada es un Numero, %d \n", teclaPulsada);//Informa a usuario de salida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else if (teclaPulsada == TECLA_EXIT) {
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Se va a salir del sistema \n"); //Informa a usuario de salida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
				exit(0);//Sale del sistema
			} else if ((teclaPulsada != '\n') && (teclaPulsada != '\r') && (teclaPulsada != 0xA)) {
				piLock(STD_IO_LCD_BUFFER_KEY);
				printf("Error: Tecla desconocida \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
				fflush(stdout);
				piUnlock(STD_IO_LCD_BUFFER_KEY);
			} else {

			}
		}
	}

	//pag 84 AP�NDICE A
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Hebra creada correctamente \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
}
#endif



#if VERSION >= 2
int ConfiguraInicializaSistema(TipoCoreWatch *p_sistema) {

	g_flagsCoreWatch = 0;

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	int resultInicializarReloj = ConfiguraInicializaReloj(&(p_sistema->reloj));
	//Recoge el resultado de la inicializacion
	if (resultInicializarReloj != 0) {
		return 1;
	}

#if VERSION >= 3
	int arrayFilas[NUM_FILAS_TECLADO];
	int arrayColumnas[NUM_COLUMNAS_TECLADO];

	//mempcy: copia arrays
	memcpy(p_sistema->teclado.filas, arrayFilas, sizeof(arrayFilas));
	memcpy(p_sistema->teclado.columnas, arrayColumnas, sizeof(arrayColumnas));

	int IniDriver;
	IniDriver = wiringPiSetupGpio();

	if (IniDriver != 0) {//Preguntar al profe qu� comparamos para ver si es correcta la inicializacion
		return 1;
	}

	ConfiguraInicializaTeclado(&(p_sistema->teclado));

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch |= FLAG_SETUP_DONE; //Activa el flag
	piUnlock(SYSTEM_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Se ha inicializado correctamente el driver\n"); //Informa a usuario de qyue se ha inicializado correctamente el driver
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif

	/////////////////////////////////////////////////////////////////////////////////////////////////////////

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf(
			"Las teclas que puede pulsar son: \n Tecla E: Tecla set cancel time \n Tecla F: Tecla para reiniciar \n Tecla B: Tecla para salir \n ");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);


#if VERSION == 2
	int resultInicializarThread = piThreadCreate(ThreadExploraTecladoPC); //Repasar como lanzar un thread con piThreadCreate, cap 4

	//Recoge resultado de la llamada
	if (resultInicializarThread != 0) {
		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("Hebra no creada correctamente \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);
		return 1;
	}
#endif

#if VERSION ==4

	p_sistema->lcdId = lcdInit(NUM_ROWS, NUM_COLS, NUM_BITS, GPIO_LCD_RS, GPIO_LCD_EN, GPIO_LCD_D0,
			GPIO_LCD_D1, GPIO_LCD_D2, GPIO_LCD_D3, GPIO_LCD_D4, GPIO_LCD_D5,
			GPIO_LCD_D6, GPIO_LCD_D7);

	if(p_sistema->lcdId == -1 ){
		return 1;
	}

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch |= FLAG_SETUP_DONE; //Activa el flag
	piUnlock(SYSTEM_KEY);

#endif

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf(" \n Configuracion completada \n ");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	return 0;
}

int EsNumero(char value) {
	//if (value < 48 || value > 57)
	//if( value < 0x30 || value > 0x39)
	if (value < '0' || value > '9') {
		return 0;
	} else {
		return 1;
	}
}

int CompruebaDigitoPulsado(fsm_t *p_this) {
	int pFlag;
	piLock(SYSTEM_KEY);
	pFlag = g_flagsCoreWatch & FLAG_DIGITO_PULSADO;	//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);
	return pFlag;

}

int CompruebaNewTimeIsReady(fsm_t *p_this) {
	int pFlag;
	////////////////////////////////////////////////////////////////////////////////////
	//Comprobar si se leen los d�gitos de la hora
	piLock(SYSTEM_KEY);
	pFlag = g_flagsCoreWatch & FLAG_NEW_TIME_IS_READY;
	piUnlock(SYSTEM_KEY);
	return pFlag;
}

int CompruebaReset(fsm_t *p_this) {
	int pFlag;

	piLock(SYSTEM_KEY);
	//Cuando sea pulsado 'F' se activa el flag
	pFlag = g_flagsCoreWatch & FLAG_RESET;//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);

	return pFlag;
}

int CompruebaSetCancelNewTime(fsm_t *p_this) {
	int pFlag;

	piLock(SYSTEM_KEY);
	//La misma tecla 'E' sirve tanto para indicar que quiero cambio hora o cancelar operacion
	pFlag = g_flagsCoreWatch & FLAG_SET_CANCEL_NEW_TIME;//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);

	return pFlag;
}

int CompruebaSetupDone(fsm_t *p_this) {
	int pFlag;
	piLock(SYSTEM_KEY);
	//El flag se activa al finalizar config e inic del sistema
	pFlag = g_flagsCoreWatch & FLAG_SETUP_DONE;	//Comprueba si se ha activado el flag
	piUnlock(SYSTEM_KEY);
	return pFlag;
}

#if VERSION >= 3
int CompruebaTeclaPulsada(fsm_t *p_this) {
	int pFlag;
	TipoTecladoShared g_tecladoSharedVarsAux = GetTecladoSharedVar();

	piLock(KEYBOARD_KEY);
	pFlag = g_tecladoSharedVarsAux.flags & FLAG_TECLA_PULSADA;	//Comprueba si se ha activado el flag
	piUnlock(KEYBOARD_KEY);

	return pFlag;
}
#endif

int CompruebaTimeActualizado(fsm_t *p_this) {
	int pFlag;
	TipoRelojShared var = GetRelojSharedVar();
	//El flag se activa al finalizar config e inic del sistema
	pFlag = var.flags & FLAG_TIME_ACTUALIZADO;//Comprueba si se ha activado el flag

	return pFlag;
}

void ShowTime(fsm_t *p_this) {
	//////////////////////////////////////////////////////////////////////////////
	//Preguntar al profe

	/*piLock(STD_IO_LCD_BUFFER_KEY);
	 printf("[STAND-BY] Showtime\n");
	 fflush(stdout);
	 piUnlock(STD_IO_LCD_BUFFER_KEY);*/
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	/////////////////////////////////////////////////////////////////////////
	TipoRelojShared var = GetRelojSharedVar();//Recoge la estructura del reloj del sistema
	piLock(RELOJ_KEY);
	var.flags &= (~FLAG_TIME_ACTUALIZADO);	//Limpia el flag
	piUnlock(RELOJ_KEY);
	SetRelojSharedVar(var);

#if VERSION <= 3
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Son las %d:%d:%d del %d/%d/%d\n", p_sistema->reloj.hora.hh,
			p_sistema->reloj.hora.mm, p_sistema->reloj.hora.ss,
			p_sistema->reloj.calendario.dd, p_sistema->reloj.calendario.MM,
			p_sistema->reloj.calendario.yyyy);
	fflush(stdout); //PREGUNTAR EN CLASE
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif

#if VERSION >= 4

	int lcdHandler = p_sistema->lcdId;
	lcdClear(lcdHandler);

	lcdPosition (lcdHandler, 0, 0);

	piLock(STD_IO_LCD_BUFFER_KEY);
	lcdPrintf(lcdHandler, "%02d:%02d:%02d", p_sistema->reloj.hora.hh,
			p_sistema->reloj.hora.mm, p_sistema->reloj.hora.ss);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	lcdPosition (lcdHandler, 0, 1);//Com probar si es 1 y 2 o en cambio es 0 y 1

	piLock(STD_IO_LCD_BUFFER_KEY);
	lcdPrintf(lcdHandler, "%02d/%02d/%04d", p_sistema->reloj.calendario.dd,
			p_sistema->reloj.calendario.MM, p_sistema->reloj.calendario.yyyy);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	lcdPosition (lcdHandler, 0, 0);
	//	delay(ESPERA_MENSAJE_MS);
	//lcdClear(p_sistema->lcdId);

#endif
}

void Start(fsm_t *p_this) {

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[STAND-BY] start\n");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SETUP_DONE);	//Limpia el flag que activa ConfiguraInicializaSistema
	piUnlock(SYSTEM_KEY);

}

void CancelSetNewTime(fsm_t *p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);
	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SET_CANCEL_NEW_TIME); //Limpia el flag que nos ha hecho llegar hasta aqu�
	piUnlock(SYSTEM_KEY);

#if VERSION < 4

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_TIME] Operacion cancelada \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif

#if VERSION >= 4
	lcdClear(p_sistema->lcdId);
	lcdPosition (p_sistema->lcdId, 0, 1);//Com probar si es 1 y 2 o en cambio es 0 y 1

	//piLock(STD_IO_LCD_BUFFER_KEY);
	lcdPrintf(p_sistema->lcdId, "CANCELADO");
	//piUnlock(STD_IO_LCD_BUFFER_KEY);

	delay(ESPERA_MENSAJE_MS);
	lcdClear(p_sistema->lcdId);

#endif
}

void PrepareSetNewTime(fsm_t *p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);
	int formatoHora = p_sistema->reloj.hora.formato;

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO);	//Limpia el flag PARA ASEGURAR QUE NO EST� ACTIVO POR HABER
	//PRESIONADO ALGBG�N N�MERO PREVIAMENTE
	piUnlock(SYSTEM_KEY);

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SET_CANCEL_NEW_TIME); //Limpia el flag que nos ha hecho llegar hasta aqu�
	piUnlock(SYSTEM_KEY);

#if VERSION < 4
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_TIME] Introduzca la nueva hora en formato 0-%d \n",
			formatoHora); //Informa a usuario de qyue ha pulsado una tecla no v�lida
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif

#if VERSION >= 4
	lcdClear(p_sistema->lcdId);
	lcdPosition (p_sistema->lcdId, 0, 1);//Com probar si es 1 y 2 o en cambio es 0 y 1

	//piLock(STD_IO_LCD_BUFFER_KEY);
	lcdPrintf(p_sistema->lcdId, "FORMAT: 0-%d", formatoHora);
	//piUnlock(STD_IO_LCD_BUFFER_KEY);

#endif

}

void ProcesaDigitoTime(fsm_t *p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	int auxDigitos = p_sistema->digitosGuardados;
	int auxTemp = p_sistema->tempTime;

	//Debería ser VERSION <= 2
#if VERSION >= 2
	int ultimoDigito = p_sistema->digitoPulsado - 48; // - 48? por ASCII
#endif

	//#if VERSION >= 3
	//	int ultimoDigito = GetTecladoSharedVar().teclaDetectada;
	//#endif

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO); // Baja la flag (En enunciado, "limpiar")
	piUnlock(SYSTEM_KEY);

	if (auxDigitos == 0) {
		if (p_sistema->reloj.hora.formato == 12) {
			ultimoDigito = MIN(1, ultimoDigito);
		} else {
			ultimoDigito = MIN(2, ultimoDigito);

		}

		auxTemp = auxTemp * 10 + ultimoDigito;
		auxDigitos = auxDigitos + 1;
	}

	else if (auxDigitos == 1) {
		if (p_sistema->reloj.hora.formato == 12) {
			if (auxTemp == 0) {
				ultimoDigito = MAX(1, ultimoDigito);
			} else { // if(p_sistema->tempTime != 0)
				ultimoDigito = MIN(2, ultimoDigito);
			}
			auxTemp = auxTemp * 10 + ultimoDigito;
			auxDigitos = auxDigitos + 1;
		}

		else { // if(p_sistema->reloj.hora.formato != 12)
			if (auxTemp == 2) {
				ultimoDigito = MIN(3, ultimoDigito);
				auxTemp = auxTemp * 10 + ultimoDigito;
			} else { // if (p_sistema->tempTime != 2)
				auxTemp = auxTemp * 10 + ultimoDigito;
			}
			auxDigitos = auxDigitos + 1;
		}
	}

	else if (auxDigitos == 2) {
		auxTemp = auxTemp * 10 + MIN(5, ultimoDigito);
		auxDigitos = auxDigitos + 1;
	} else if (auxDigitos == 3) {
		auxTemp = auxTemp * 10 + ultimoDigito;

		piLock(SYSTEM_KEY);
		g_flagsCoreWatch &= (~FLAG_DIGITO_PULSADO); // Limpio la flag "Por seguridad" -- BAJAR
		piUnlock(SYSTEM_KEY);
		piLock(SYSTEM_KEY);
		g_flagsCoreWatch |= FLAG_NEW_TIME_IS_READY; // Activo FLAG_NEW_TIME_IS_READY -- SUBIR
		piUnlock(SYSTEM_KEY);
	}
	if (auxDigitos < 3) {
		if (auxTemp > 2359) {
			auxTemp %= 10000;
			auxTemp = 100 * MIN((int )(auxTemp / 100), 23)
			+ MIN(auxTemp % 100, 59);
		}
	}
	p_sistema->tempTime = auxTemp;
	p_sistema->digitosGuardados = auxDigitos;

#if VERSION < 4
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_TIME]: Nueva hora temporal %d\n", p_sistema->tempTime); // Informo al usuario del valor de tempTime
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif

#if VERSION == 4
	//////////////////////////////////////////////////////////////
	/// PREGUNTAR AL PROFE CON LIMPIAR PRIMERA LINEA//////////////
	/// //////////////////////////////////////////////////////////
	//lcdPuts(p_sistema->lcdId, "      ");

	lcdClear(p_sistema->lcdId);
	lcdPosition(p_sistema->lcdId, 0, 0);
	piLock(STD_IO_LCD_BUFFER_KEY);
	lcdPrintf(p_sistema->lcdId, "SET: %d", p_sistema->tempTime);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

#endif
}

void ProcesaTeclaPulsada(fsm_t *p_this) {
	//Anologo a Thread VERSION 2
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	TipoTecladoShared g_tecladoSharedVarsAux;
	g_tecladoSharedVarsAux = GetTecladoSharedVar();

	piLock(SYSTEM_KEY);
	g_tecladoSharedVarsAux.flags &= (~FLAG_TECLA_PULSADA); //Limpia el flag que nos ha hecho llegar hasta aqui
	piUnlock(SYSTEM_KEY);

	SetTecladoSharedVar(g_tecladoSharedVarsAux);

	char teclaPulsada = g_tecladoSharedVarsAux.teclaDetectada;


	if (teclaPulsada == TECLA_RESET) {
		piLock(SYSTEM_KEY);
		g_flagsCoreWatch |= FLAG_RESET; //Activa flag
		piUnlock(SYSTEM_KEY);
		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("Has pulsado tecla F \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);

	} else if (teclaPulsada == TECLA_SET_CANCEL_TIME) {
		piLock(SYSTEM_KEY);
		g_flagsCoreWatch |= FLAG_SET_CANCEL_NEW_TIME; //Activa flag
		piUnlock(SYSTEM_KEY);

		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("Has pulsado tecla E \n");//Informa a usuario de qyue ha pulsado una tecla no v�lida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);

	} else if (EsNumero(teclaPulsada)) {
		g_corewatch.digitoPulsado = teclaPulsada; //Nuestra tecla pulsda es el digito pulsado del reloj

		piLock(SYSTEM_KEY);
		g_flagsCoreWatch |= FLAG_DIGITO_PULSADO;//Activa flag
		piUnlock(SYSTEM_KEY);

		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("La Tecla Pulsada es un Numero, %d \n", teclaPulsada);//Informa a usuario de salida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);
	} else if (teclaPulsada == TECLA_EXIT) {
		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("Se va a salir del sistema \n"); //Informa a usuario de salida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);

		lcdClear(p_sistema->lcdId);
		lcdPosition(p_sistema->lcdId, 0, 0);

		piLock(STD_IO_LCD_BUFFER_KEY);
		lcdPrintf(p_sistema->lcdId, "GAME OVER");
		piUnlock(STD_IO_LCD_BUFFER_KEY);

		exit(0);//Sale del sistema
	} else if ((teclaPulsada != '\n') && (teclaPulsada != '\r') && (teclaPulsada != 0xA)) {
		piLock(STD_IO_LCD_BUFFER_KEY);
		printf("Error: Tecla desconocida \n"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
		fflush(stdout);
		piUnlock(STD_IO_LCD_BUFFER_KEY);

		piLock(STD_IO_LCD_BUFFER_KEY);
			lcdPrintf(p_sistema->lcdId, "Error tecla");
		piUnlock(STD_IO_LCD_BUFFER_KEY);
	} else {

	}

}

void Reset(fsm_t *p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);
	ResetReloj(&(p_sistema->reloj));

	/*piLock(STD_IO_LCD_BUFFER_KEY);
	 printf("[STAND-BY] Reset\n");
	 fflush(stdout);
	 piUnlock(STD_IO_LCD_BUFFER_KEY);
	 */
	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_RESET); //Limpia el flag que nos ha hecho llegar hasta aqui
	piUnlock(SYSTEM_KEY);

#if VERSION < 4
	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[RESET] Hora reiniciada \n");
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);
#endif

#if VERSION >= 4
	lcdClear(p_sistema->lcdId);
	lcdPosition (p_sistema->lcdId, 0, 1);//Com probar si es 1 y 2 o en cambio es 0 y 1

	piLock(STD_IO_LCD_BUFFER_KEY);
	lcdPrintf(p_sistema->lcdId, "RESET", p_sistema->reloj.hora.formato);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	delay(ESPERA_MENSAJE_MS);
	lcdClear(p_sistema->lcdId);
#endif

}

void SetNewTime(fsm_t *p_this) {
	TipoCoreWatch *p_sistema = (TipoCoreWatch*) (p_this->user_data);

	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_NEW_TIME_IS_READY); //Limpia el flag que nos ha hecho llegar hasta aqu�
	piUnlock(SYSTEM_KEY);

	SetHora(p_sistema->tempTime, (&(p_sistema->reloj.hora)));

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("[SET_NEW_TIME] La hora usada en SetHora es %d \n",
			p_sistema->tempTime);
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;
}
#endif
int main() {
	unsigned int next;
	//TipoReloj relojPrueba; //Despues va ConfiguraInicializaSesion

	fsm_t *fsmReloj = fsm_new(WAIT_TIC, g_fsmTransReloj, &(g_corewatch.reloj));
	fsm_t *fsmCoreWatch = fsm_new(START, fsmTransCoreWatch, &(g_corewatch));
	fsm_t *deteccionComandosFSM = fsm_new(WAIT_COMMAND, fsmTransDeteccionComandos, &(g_corewatch));
	fsm_t *tecladoFSM = fsm_new(WAIT_COMMAND, g_fsmTransExcitacionColumnas, &(g_corewatch.teclado));

#if VERSION <= 1
	//TipoReloj relojPrueba; //Despues va ConfiguraInicializaSesion
	ConfiguraInicializaReloj(&relojPrueba);
	SetHora(2359, &(relojPrueba.hora));

#endif

#if VERSION >= 2
	int resultConfig = ConfiguraInicializaSistema(&g_corewatch);


	if (resultConfig != 0) {
		printf("Error: Se va a salir del sistema \n"); //Informa a usuario de salida
		fflush(stdout);
		exit(0); //Sale del sistema
	}
#endif

	next = millis();
	while (1) {
		fsm_fire(fsmReloj);
		fsm_fire(fsmCoreWatch);
		fsm_fire(deteccionComandosFSM);
		fsm_fire(tecladoFSM);

		next += CLK_MS;
		DelayUntil(next);
	}
	tmr_destroy(g_corewatch.reloj.tmrTic);
	fsm_destroy(fsmReloj);
	fsm_destroy(fsmCoreWatch);
	fsm_destroy(g_corewatch.teclado.tmr_duracion_columna->timerid);
	fsm_destroy(deteccionComandosFSM);
	fsm_destroy(tecladoFSM);
}
