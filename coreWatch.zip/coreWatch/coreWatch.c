#include "coreWatch.h"
#include "kbhit.h"

fsm_trans_t g_fsmTransReloj[] = {
		{ START, CompruebaSetupDone, STAND_BY, Start }, { STAND_BY,
				CompruebaTimeActualizado, STAND_BY, ShowTime }, { STAND_BY,
				CompruebaReset, STAND_BY, Reset }, { STAND_BY,
				CompruebaSetCancelNewTime, SET_TIME, PrepareSetNewTime }, {
				SET_TIME, CompruebaDigitoPulsado, SET_TIME, ProcesaDigitoTime },
		{ SET_TIME, CompruebaSetCancelNewTime, STAND_BY, CancelSetNewTime }, {
				SET_TIME, CompruebaNewTimeIsReady, STAND_BY, SetNewTime }, { -1,
		NULL, -1, NULL }, };

TipoCoreWatch g_corewatch;
static int g_flagsCoreWatch;

//volatile int flags = 0;

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
// Wait until next_activation (absolute time)
// Necesita de la función "delay" de WiringPi.
void DelayUntil(unsigned int next) {
	unsigned int now = millis();
	if (next > now) {
		delay(next - now);
	}
}

//------------------------------------------------------
// MAIN
//fflush(stdout) vacia para forzar que se haga lo que hemos pedido
//------------------------------------------------------
int main() {
	unsigned int next;
	TipoReloj relojPrueba; //Despues va ConfiguraInicializaSesion

#if VERSION <= 1
	TipoReloj relojPrueba; //Despues va ConfiguraInicializaSesion
	ConfiguraInicializaReloj(&relojPrueba);
	SetHora(2359, &(relojPrueba.hora));

#endif

	int resultConfig = ConfiguraInicializaSistema(&g_corewatch);
	if (resultConfig != 0) {
		printf("Error: Se va a salir del sistema"); //Informa a usuario de salida
		fflush(stdout);
		exit(0); //Sale del sistema
	}

	fsm_t* fsmReloj = fsm_new(WAIT_TIC, g_fsmTransReloj, &(relojPrueba));
	next = millis();
	while (1) {
		fsm_fire(fsmReloj);

		next += CLK_MS;
		DelayUntil(next);
	}
}

#if VERSION >= 2

PI_THREAD(ThreadExploraTecladoPC) {

	int teclaPulsada;
	while (1) {
		delay(10);

		if (kbhit()) { //Est� pulsada una tecla
			teclaPulsada = kbread();
		}
		if (teclaPulsada == TECLA_RESET) {
			piLock(KEYBOARD_KEY);
			g_flagsCoreWatch |= FLAG_RESET; //Activa flag
			piUnlock(KEYBOARD_KEY);
		} else if (teclaPulsada == TECLA_SET_CANCEL_TIME) {
			piLock(KEYBOARD_KEY);
			g_flagsCoreWatch |= FLAG_SET_CANCEL_NEW_TIME; //Activa flag
			piUnlock(KEYBOARD_KEY);
		} else if (EsNumero(teclaPulsada)) {
			g_corewatch.digitoPulsado = teclaPulsada; //Nuestra tecla pulsda es el digito pulsado del reloj
			piLock(KEYBOARD_KEY);
			g_flagsCoreWatch |= FLAG_DIGITO_PULSADO; //Activa flag
			piUnlock(KEYBOARD_KEY);
		} else if (teclaPulsada == TECLA_EXIT) {
			printf("Se va a salir del sistema"); //Informa a usuario de salida
			fflush(stdout);
			exit(0); //Sale del sistema
		} else if ((teclaPulsada != '\n') && (teclaPulsada != '\r')
				&& (teclaPulsada != 0xA)) {
			printf("Error: Tecla desconocida"); //Informa a usuario de qyue ha pulsado una tecla no v�lida
			fflush(stdout);
		}
	}

	//pag 84 AP�NDICE A

}

int ConfiguraInicializaSistema(TipoCoreWatch *p_sistema) {
	g_flagsCoreWatch = 0;

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	int resultInicializarReloj = ConfiguraInicializaReloj(&p_sistema->reloj);
	//Recoge el resultado de la inicializacion
	if (resultInicializarReloj == 0) {
		return 1;
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	printf(
			"Las teclas que puede pulsar son: \n Tecla E: Tecla set cancel time \n Tecla F: Tecla para reiniciar \n Tecla B: Tecla para salir ");
	fflush(stdout);
/////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*resultInicializarThread = piThreadCreate(ThreadExploraTecladoPC);//Repasar como lanzar un thread con piThreadCreate, cap 4
	 //Recoge resultado de la llamada
	 if (resultInicializarThread != 0){
	 return 2;
	 }*/
	return 0;
}

int EsNumero(char value) {
	//if( value < '0' || value > '9')
	//if( value < 0x30 || value > 0x39)
	if (value < 48 || value > 57) {
		return 0;
	} else {
		return 1;
	}
}

int CompruebaDigitoPulsado(fsm_t* p_this) {
	int result = 0;
	if ((g_flagsCoreWatch && FLAG_DIGITO_PULSADO) == 1) {//Comprueba si se ha activado el flag
		piLock(SYSTEM_KEY);
		result = 1;
		piUnlock(SYSTEM_KEY);
		return result;
	}
	return result;

}

int CompruebaNewTimeIsReady(fsm_t* p_this) {
	int result = 0;
////////////////////////////////////////////////////////////////////////////////////
//Comprobar si se leen los d�gitos de la hora

	if ((g_flagsCoreWatch && FLAG_NEW_TIME_IS_READY) == 1) {//Comprueba si se ha activado el flag
		piLock(SYSTEM_KEY);
		result = 1;
		piUnlock(SYSTEM_KEY);
		return result;
	}

	return result;
}

int CompruebaReset(fsm_t* p_this) {
	int result = 0;
	//Cuando sea pulsado 'F' se activa el flag
	if ((g_flagsCoreWatch && FLAG_RESET) == 1) {//Comprueba si se ha activado el flag
		piLock(SYSTEM_KEY);
		result = 1;
		piUnlock(SYSTEM_KEY);
		return result;
	}
	return result;

}

int CompruebaSetCancelNewTime(fsm_t* p_this) {
	int result = 0;
	//La misma tecla 'E' sirve tanto para indicar que quiero cambio hora o cancelar operacion
	if ((g_flagsCoreWatch && FLAG_SET_CANCEL_NEW_TIME) == 1) {//Comprueba si se ha activado el flag
		piLock(SYSTEM_KEY);
		result = 1;
		piUnlock(SYSTEM_KEY);
		return result;
	}
	return result;

}

int CompruebaSetupDone(fsm_t* p_this) {
	int result = 0;
	//El flag se activa al finalizar config e inic del sistema
	if ((g_flagsCoreWatch && FLAG_SETUP_DONE) == 1) {//Comprueba si se ha activado el flag
		piLock(SYSTEM_KEY);
		result = 1;
		piUnlock(SYSTEM_KEY);
		return result;
	}
	return result;
}

int CompruebaTeclaPulsada(fsm_t* p_this) {
	//VERSION 3
	return 0;
}

int CompruebaTimeActualizado(fsm_t* p_this) {

	return 0;
}

void Start(fsm_t* p_this) {
	piLock(SYSTEM_KEY);
	g_flagsCoreWatch &= (~FLAG_SETUP_DONE);	//Limpia el flag
	piUnlock(SYSTEM_KEY);

}

void ShowTime(fsm_t* p_this) {
	//////////////////////////////////////////////////////////////////////////////
	//Preguntar al profe
	//TipoCoreWatch p_sistema = (TipoCoreWatch)p_this;
	//p_sistema = g_corewatch;
	/////////////////////////////////////////////////////////////////////////
	TipoRelojShared var = GetRelojSharedVar();
	piLock(SYSTEM_KEY);
	var.flags &= (~FLAG_TIME_ACTUALIZADO);
	piUnlock(SYSTEM_KEY);

}

#endif
