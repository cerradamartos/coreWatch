#include "coreWatch.h"
#include "reloj.h"

fsm_trans_t g_fsmTransReloj[] = {{WAIT_TIC, CompruebaTic, WAIT_TIC, ActualizaReloj},
								{-1, "NULL", -1, "NULL"},};

TipoCoreWatch g_corewatch;
static int g_flagsCoreWatch;

volatile int flags = 0;

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
// Wait until next_activation (absolute time)
// Necesita de la función "delay" de WiringPi.
void DelayUntil(unsigned int next) {
	unsigned int now = millis();
	if (next > now) {
		delay(next - now);
	}
}


//------------------------------------------------------
// MAIN
//fflush(stdout) vacia para forzar que se haga lo que hemos pedido
//------------------------------------------------------
int main() {
	unsigned int next;

#if VERSION <= 1
TipoReloj relojPrueba;//Despues va ConfiguraInicializaSesion
ConfiguraInicializaReloj(&relojPrueba);
#endif

fsm_t* fsmReloj = fsm_new(WAIT_TIC, g_fsmTransReloj, &(relojPrueba));
	next = millis();
	while (1) {
		fsm_fire(fsmReloj);

		next += CLK_MS;
		DelayUntil(next);
	}
}
//#if VERSION >= 2
int ConfiguraInicializaSistema(TipoCoreWatch *p_sistema){
	g_flagsCoreWatch = 0;

	p_sistema->tempTime = 0;
	p_sistema->digitosGuardados = 0;

	int resultInicializarReloj = ConfiguraInicializaReloj(&p_sistema->reloj);
	//Recoge el resultado de la inicialización
	if (resultInicializarReloj == 0) {
		return 1;
	}

	int resultInicializarThread = piThreadCreate(ThreadExploraTecladoPC);
	//Recoge resultado de la llamada
	if (resultInicializarThread == 0){
		return 2;
	}
return 0;

//Repasar cómo lanzar un thread con piThreadCreate, cap 4

}
//#endif
