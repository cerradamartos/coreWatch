#include "coreWatch.h"
#include "reloj.h"
//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
// Wait until next_activation (absolute time)
// Necesita de la función "delay" de WiringPi.
void DelayUntil(unsigned int next) {
	unsigned int now = millis();
	if (next > now) {
		delay(next - now);
	}
}


//------------------------------------------------------
// MAIN
//fflush(stdout) vacia para forzar que se haga lo que hemos pedido
//------------------------------------------------------
int main() {
	unsigned int next;

#if VERSION <= 1
TipoReloj relojPrueba;//Despues va ConfiguraInicializaSesion
ConfiguraInicializaReloj(&relojPrueba);
#endif

fsm_t* fsmReloj = fsm_new(WAIT_TIC, g_fsmTransReloj, &(relojPrueba));
	next = millis();
	while (1) {
		fsm_fire(fsmReloj);

		next += CLK_MS;
		DelayUntil(next);
	}
}
