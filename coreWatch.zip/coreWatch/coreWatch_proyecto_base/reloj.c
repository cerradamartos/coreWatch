/*
 * reloj.c
 *
 *  Created on: 11 de feb. de 2022
 *      Author: alumno
 */

#include "reloj.h"
#include "tmr.h"

//variable global g_relojSharedVars

fsm_trans_t g_fsmTransReloj[] = {{WAIT_TIC, CompruebaTic, WAIT_TIC, ActualizaReloj},
								{-1, NULL, -1, NULL},};
const int DIAS_MESES_BISIESTOS[MAX_MONTH]= {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};//num d�as cada mes a�os bisiestos
const int DIAS_MESES_NO_BISIESTOS[MAX_MONTH]= {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};//num d�as cada mes a�os no bisiestos

static TipoRelojShared g_relojSharedVars;

void ResetReloj (TipoReloj *p_reloj){
	TipoCalendario calendario;
		calendario.dd= DEFAULT_DAY;
		calendario.MM = DEFAULT_MONTH;
		calendario.yyyy = DEFAULT_YEAR;
	p_reloj->calendario = calendario;//pasamos al reloj el calendario creado anteriormente
	TipoHora hora;
	hora.hh = DEFAULT_HOUR;
	hora.mm = DEFAULT_MIN;
	hora.ss = DEFAULT_SEC;
	hora.formato = DEFAULT_TIME_FORMAT;
	p_reloj->hora = hora;
	p_reloj->timestamp = 0;//SI PONES ASTERISCO SERA OBJETO, PON PUNTO; SI NO PONES ASTERISCO, PON FLECHA
	piLock (RELOJ_KEY);
	g_relojSharedVars.flags = 0;
	piUnlock (RELOJ_KEY);
}

void tmr_actualiza_reloj_isr (union sigval value){
	piLock (RELOJ_KEY);
	g_relojSharedVars.flags = 0;
	piUnlock (RELOJ_KEY);
}

int ConfiguraInicializaReloj(TipoReloj *p_reloj){
	ResetReloj(p_reloj);
	p_reloj->tmrTic = tmr_new (tmr_actualiza_reloj_isr);
	if (p_reloj->tmrTic == NULL)
		return 1;
	tmr_startms_periodic(p_reloj->tmrTic, PRECISION_RELOJ_MS);
	return 0;
}

int CompruebaTic(fsm_t* p_this){
	if (g_relojSharedVars.flags == 0){

	}

}


