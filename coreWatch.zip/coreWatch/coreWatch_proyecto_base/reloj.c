/*
 * reloj.c
 *
 *  Created on: 11 de feb. de 2022
 *      Author: alumno
 */

#include "reloj.h"

//variable global g_relojSharedVars

