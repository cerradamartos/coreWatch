/*
 * reloj.c
 *
 *  Created on: 11 de feb. de 2022
 *      Author: alumno
 */

#include "reloj.h"
#include "tmr.h"
#include "util.h"


//variable global g_relojSharedVars

fsm_trans_t g_fsmTransReloj[] = {{WAIT_TIC, CompruebaTic, WAIT_TIC, ActualizaReloj},
								{-1, NULL, -1, NULL},};//Maquina de estados fsm
const int DIAS_MESES_BISIESTOS[MAX_MONTH]= {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};//num d�as cada mes a�os bisiestos
const int DIAS_MESES_NO_BISIESTOS[MAX_MONTH]= {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};//num d�as cada mes a�os no bisiestos

volatile int flags = 0;

static TipoRelojShared g_relojSharedVars;

void ResetReloj (TipoReloj *p_reloj){
	TipoCalendario calendario;
		calendario.dd= DEFAULT_DAY;
		calendario.MM = DEFAULT_MONTH;
		calendario.yyyy = DEFAULT_YEAR;
	p_reloj->calendario = calendario;//pasamos al reloj el calendario creado anteriormente
	TipoHora hora;
	hora.hh = DEFAULT_HOUR;
	hora.mm = DEFAULT_MIN;
	hora.ss = DEFAULT_SEC;
	hora.formato = DEFAULT_TIME_FORMAT;
	p_reloj->hora = hora;
	p_reloj->timestamp = 0;//SI PONES ASTERISCO SERA OBJETO, PON PUNTO; SI NO PONES ASTERISCO, PON FLECHA

	piLock (RELOJ_KEY);
	g_relojSharedVars.flags = 0;
	piUnlock (RELOJ_KEY);
}

void tmr_actualiza_reloj_isr (union sigval value){
	 piLock (RELOJ_KEY);
	 g_relojSharedVars.flags |= FLAG_ACTUALIZA_RELOJ;//Activa el flag
	 piUnlock (RELOJ_KEY);
}

int ConfiguraInicializaReloj(TipoReloj *p_reloj){
	ResetReloj(p_reloj);
	p_reloj->tmrTic = tmr_new (tmr_actualiza_reloj_isr);
	if (p_reloj->tmrTic == NULL)
		return 1;
	tmr_startms_periodic(p_reloj->tmrTic, PRECISION_RELOJ_MS);
	return 0;
}

int CompruebaTic(fsm_t* p_this){
        int result = 0;
        if((g_relojSharedVars.flags && FLAG_ACTUALIZA_RELOJ) == 0){
        piLock (RELOJ_KEY);
        result = 1;
        piUnlock (RELOJ_KEY);
        return result;
        }
        return result;
}

void ActualizaReloj(fsm_t* p_this){
        TipoReloj *p_miReloj = (TipoReloj*)(p_this->user_data);
        p_miReloj->timestamp++;
        //ActualizaHora(&p_miReloj->hora); //quitar comentario
        if(p_miReloj->hora.hh ==0 && p_miReloj->hora.mm ==0 && p_miReloj->hora.ss ==0){
        //ActualizaFecha(p_miReloj->calendario);//quitar comentario

        }
        g_relojSharedVars.flags &= (~FLAG_ACTUALIZA_RELOJ);//Limpia el flag
        g_relojSharedVars.flags |= FLAG_TIME_ACTUALIZADO;//Activa flag

#if VERSION == 1
	printf("Son las %d:%d:%d del %d/%d/%d\n", p_miReloj->hora.hh, p_miReloj->hora.mm, p_miReloj->hora.ss,
			p_miReloj->calendario.dd, p_miReloj->calendario.MM, p_miReloj->calendario.yyyy);
	fflush(stdout); //PREGUNTAR EN CLASE
#endif
}

void ActualizaFecha (TipoCalendario *p_fecha){
	int auxd = 0;int maxd = 0;
	int auxm = 0;int maxm = 0;
	CalculaDiasMes (p_fecha->MM, p_fecha->yyyy);
//Si S� es Bisiesto
	if (EsBisiesto(p_fecha->yyyy) == 1){
		auxd = (p_fecha->dd+1)%(DIAS_MESES_BISIESTOS[p_fecha->MM]+1);
		maxd = MAX(auxd, 1);
		p_fecha->dd = maxd;

		if (p_fecha->dd == 1){
			auxm = (p_fecha->MM+1)%(MAX_MONTH+1);
			maxm = MAX(auxm, 1);
			p_fecha->MM = maxm;
		}
		if (p_fecha->dd == 1 && p_fecha->MM == 1){
			int auxy = 0;
			auxy = p_fecha->yyyy++;
			p_fecha->yyyy = auxy;
		}
	}
//Si NO es Bisiesto ///DESCRIBIR ALGORITMO DE LA NOCHE
	if (EsBisiesto(p_fecha->yyyy) == 0){
			auxd = (p_fecha->dd+1)%(DIAS_MESES_NO_BISIESTOS[p_fecha->MM]+1);
			maxd = MAX(auxd, 1);
			p_fecha->dd = maxd;

			if (p_fecha->dd == 1){
				auxm = (p_fecha->MM+1)%(MAX_MONTH+1);
				maxm = MAX(auxm, 1);
				p_fecha->MM = maxm;
			}
			if (p_fecha->dd == 1 && p_fecha->MM == 1){
				int auxy = 0;
				auxy = p_fecha->yyyy++;
				p_fecha->yyyy = auxy;
			}
		}
}
void ActualizaHora(TipoHora *p_hora){
	int auxss = 0;
	auxss = (p_hora->ss+1)%60;
	p_hora->ss = auxss;
	if (p_hora->ss == 0){
		int auxmm = 0;
		auxmm = (p_hora->mm+1)%60;
		p_hora->mm = auxmm;
		if (p_hora->ss == 0 && p_hora->mm == 0){
			int auxhh = 0;
			p_hora->hh++;
			auxhh = (TIME_FORMAT_24_H)%(p_hora->formato);
			p_hora->hh = auxhh;
		}
	}
}
int CalculaDiasMes (int month, int year){/////A�o Actual = A�o Introducido???
	//Si S� es Bisiesto
	if (EsBisiesto(year) == 1){
		return DIAS_MESES_BISIESTOS[month];
	}
	//Si NO es Bisiesto
	else{
		return DIAS_MESES_NO_BISIESTOS[month];
	}
}
//Si devuelve 1 Si es Bisiesto
int EsBisiesto(int year){
	if((year%4) == 0){
		if((year%100) == 0){
			if((year%400) == 0){
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return 1;
		}
	}
	return 0;
}
TipoRelojShared GetRelojSharedVar(){
	TipoRelojShared g_relojSharedVarsAux = g_relojSharedVars;
	piLock (RELOJ_KEY);
	return g_relojSharedVarsAux;
	piUnlock (RELOJ_KEY);
}

void SetRelojSharedVar (TipoRelojShared value){
	piLock (RELOJ_KEY);
	value = g_relojSharedVars;
	piUnlock (RELOJ_KEY);
}
