/*
 * reloj.h
 *
 *  Created on: 11 de feb. de 2022
 *      Author: alumno
 */
#include "systemConfig.h"
#include "util.h"
//#include "coreWatch.h"

enum FSM_ESTADOS_RELOJ {WAIT_TIC};

#define MIN_DAY 1
#define MAX_MONTH 12
#define MIN_MONTH 1
#define MIN_YEAR 1970
#define MIN_HOUR 0
#define MAX_HOUR 23
#define MAX_MIN 59
#define MAX_SEG 59
#define TIME_FORMAT_24_H 24
#define PRECISION_RELOJ_MS 1000
#define DEFAULT_DAY 1
#define DEFAULT_MONTH 1
#define DEFAULT_YEAR 1970
#define DEFAULT_HOUR 12
#define DEFAULT_MIN 0
#define DEFAULT_SEC 0
#define DEFAULT_TIME_FORMAT 24

#define FLAG_ACTUALIZA_RELOJ 0x01
#define FLAG_TIME_ACTUALIZADO 0x02

typedef struct {
	int dd;
	int MM;
	int yyyy;
} TipoCalendario;

typedef struct {
	int hh;
	int mm;
	int ss;
	int formato;
} TipoHora;

typedef struct {
	int timestamp;
	TipoHora hora;
	TipoCalendario calendario;
	tmr_t* tmrTic;
} TipoReloj;

typedef struct {
	int flags;
} TipoRelojShared;

extern fsm_trans_t g_fsmTransReloj[];//array tabla de transiciones de la fsm de reloj
extern const int DIAS_MESES_BISIESTOS[MAX_MONTH];//num d�as cada mes a�os bisiestos
extern const int DIAS_MESES_NO_BISIESTOS[MAX_MONTH];//num d�as cada mes a�os no bisiestos

//
//FUNCIONES DE INICIALZACION DE LAS VARIABLES
//
int ConfiguraInicializaReloj(TipoReloj *p_reloj);//configura reloj
void ResetReloj (TipoReloj *p_reloj);
//
//FUNCIONES PROPIAS
//
void ActualizaFecha (TipoCalendario *p_fecha);//actualiza dia mes y a�o
void ActualizaHora(TipoHora *p_hora);//actualiza hora min seg
int CalculaDiasMes (int month, int year);//comprueba si a�o es bisiesto para dar num dias mes
int EsBisiesto (int year);//compreuba si es bisiesto
TipoRelojShared GetRelojSharedVar();//
//SetFecha, Set Formato???
int SetHora (int horaInt, TipoHora *p_hora);//
void SetRelojSharedVar (TipoRelojShared value);//
//FUNCIONES DE ENTRADA DE LA M�QUINA DE ESTADOS
int CompruebaTic(fsm_t* p_this);//comprueba si el FLAG_ACTUALIZA_RELOJ ha sido activado por el temp.(Usa mutex reloj)
//FUNCIONES DE ENTRADA DE LA MAQUINA DE ESTADOS
void ActualizaReloj(fsm_t* p_this);//actualiza hora y fecha reloj (Usa mutex reloj) ver apendice B

//SUBRUTINAS DE ATENCION A LAS INTERRUPCIONES
void tmr_actualiza_reloj_isr (union sigval value);//subrut. aten. inter. que marca tic de un seg en reloj, activa FLAG_ACTUALIZA_RELOJ


#ifndef COREWATCH_PROYECTO_BASE_RELOJ_H_
#define COREWATCH_PROYECTO_BASE_RELOJ_H_
//INCLUDES
//DEFINES Y ENUMS
//FLAGS FSM
//DECLARACION ESTRUCTURAS
//DECLARACION VARIABLES
//DEFINICION VARIABLES

//FUNCIONES DE INICIALZACION DE LAS VARIABLES
//FUNCIONES PROPIAS
//FUNCIONES DE ENTRADA DE LA MAQUINA DE ESTADOS
//FUNCIONES DE LA SALIDA DE LA MAQUINA DE ESTADOS

//SUBRUTINAS DE ATENCION A LAS INTERRUPCIONES
//FUNCIONES LIGADAS A THREADS ADICIONALES

#endif /* COREWATCH_PROYECTO_BASE_RELOJ_H_ */
