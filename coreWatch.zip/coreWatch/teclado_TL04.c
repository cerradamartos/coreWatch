#include "teclado_TL04.h"

const char tecladoTL04[NUM_FILAS_TECLADO][NUM_COLUMNAS_TECLADO] = {
		{'1', '2', '3', 'C'},
		{'4', '5', '6', 'D'},
		{'7', '8', '9', 'E'},
		{'A', '0', 'B', 'F'}
};

// Maquina de estados: lista de transiciones
// {EstadoOrigen, CondicionDeDisparo, EstadoFinal, AccionesSiTransicion }
fsm_trans_t g_fsmTransExcitacionColumnas[] = {
		{ TECLADO_ESPERA_COLUMNA, CompruebaTimeoutColumna, TECLADO_ESPERA_COLUMNA, TecladoExcitaColumna },
		{-1, NULL, -1, NULL },
};

static TipoTecladoShared g_tecladoSharedVars;

//------------------------------------------------------
// FUCNIONES DE INICIALIZACION DE LAS VARIABLES ESPECIFICAS
//------------------------------------------------------
void ConfiguraInicializaTeclado(TipoTeclado *p_teclado) {
// A completar por el alumno...


	// Inicializacion de elementos de la variable global de tipo TipoTecladoShared:
	// 1. Valores iniciales de todos los "debounceTime"
	// 2. Valores iniciales de todos "columnaActual", "teclaDetectada" y "flags"

	g_tecladoSharedVars.debounceTime[0] = DEBOUNCE_TIME_MS;//preguntar como inicializar a 0 el array
	g_tecladoSharedVars.columnaActual = COLUMNA_1;
	g_tecladoSharedVars.teclaDetectada = "h";


	g_tecladoSharedVars.flags = 0;


	// Inicializacion de elementos de la estructura TipoTeclado:
	// Inicializacion del HW:
	// 1. Configura GPIOs de las columnas:
	// 	  (i) Configura los pines y (ii) da valores a la salida
	// 2. Configura GPIOs de las filas:
	// 	  (i) Configura los pines y (ii) asigna ISRs (y su polaridad)
	//


	// Inicializacion del temporizador:
	// 3. Crear y asignar temporizador de excitacion de columnas
	// 4. Lanzar temporizador

	p_teclado->tmr_duracion_columna = tmr_new (timer_duracion_columna_isr);

	tmr_init(p_teclado->tmr_duracion_columna, timer_duracion_columna_isr);

}

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
/* Getter y setters de variables globales */

TipoTecladoShared GetTecladoSharedVar() {
	TipoTecladoShared result;

	piLock (KEYBOARD_KEY);
	result = g_tecladoSharedVars;
	piUnlock (KEYBOARD_KEY);

	return result;

}
void SetTecladoSharedVar(TipoTecladoShared value) {

	piLock (KEYBOARD_KEY);
	g_tecladoSharedVars = value;
	piUnlock (KEYBOARD_KEY);
}

void ActualizaExcitacionTecladoGPIO(int columna) {
	// ATENCION: Evitar que este mas de una columna activa a la vez.

	// A completar por el alumno
	// ...
	switch(columna){
	// ...
	}
}

//------------------------------------------------------
// FUNCIONES DE ENTRADA O DE TRANSICION DE LA MAQUINA DE ESTADOS
//------------------------------------------------------
int CompruebaTimeoutColumna(fsm_t* p_this) {
	int result = 0;

	piLock(KEYBOARD_KEY);
	result = g_tecladoSharedVars & FLAG_TIMEOUT_COLUMNA_TECLADO;	//Comprueba si se ha activado el flag
	piUnlock(KEYBOARD_KEY);

	return result;
}


//------------------------------------------------------
// FUNCIONES DE SALIDA O DE ACCION DE LAS MAQUINAS DE ESTADOS
//------------------------------------------------------
void TecladoExcitaColumna(fsm_t* p_this) {
	TipoTeclado *p_teclado = (TipoTeclado*)(p_this->user_data);

	// 1. Actualizo que columna SE VA a excitar
	// 2. Ha pasado el timer y es hora de excitar la siguiente columna:
	//    (i) Llamada a ActualizaExcitacionTecladoGPIO con columna A ACTIVAR como argumento
	// 3. Actualizar la variable flags
	// 4. Manejar el temporizador para que vuelva a avisarnos

	p_teclado->columnas = gpio_col[g_tecladoSharedVars.columnaActual];

	ActualizaExcitacionTecladoGPIO(p_teclado->columnas);

	g_tecladoSharedVars.flags = FLAG_TIMEOUT_COLUMNA_TECLADO;





}

//------------------------------------------------------
// SUBRUTINAS DE ATENCION A LAS INTERRUPCIONES
//------------------------------------------------------
void teclado_fila_1_isr(void) {
	// 1. Comprobar si ha pasado el tiempo de guarda de anti-rebotes
	// 2. Atender a la interrupcion:
	// 	  (i) Guardar la tecla detectada en g_tecladoSharedVars
	//    (ii) Activar flag para avisar de que hay una tecla pulsada
	// 3. Actualizar el tiempo de guarda del anti-rebotes

	if(millis () < g_tecladoSharedVars.debounceTime){
		g_tecladoSharedVars.debounceTime = millis () + DEBOUNCE_TIME_MS;
		return;
	}

	char tecla = g_tecladoSharedVars.teclaDetectada;
	piLock(KEYBOARD_KEY);
	tecla |= FLAG_TECLA_PULSADA;
	piUnlock(KEYBOARD_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	g_tecladoSharedVars.debounceTime = millis () + DEBOUNCE_TIME_MS;

}

void teclado_fila_2_isr(void) {
	if (millis() < g_tecladoSharedVars.debounceTime) {
		g_tecladoSharedVars.debounceTime = millis() + DEBOUNCE_TIME_MS;
		return;
	}

	char tecla = g_tecladoSharedVars.teclaDetectada;
	piLock(KEYBOARD_KEY);
	tecla |= FLAG_TECLA_PULSADA;
	piUnlock(KEYBOARD_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	g_tecladoSharedVars.debounceTime = millis() + DEBOUNCE_TIME_MS;
}

void teclado_fila_3_isr(void) {
	if (millis() < g_tecladoSharedVars.debounceTime) {
		g_tecladoSharedVars.debounceTime = millis() + DEBOUNCE_TIME_MS;
		return;
	}

	char tecla = g_tecladoSharedVars.teclaDetectada;
	piLock(KEYBOARD_KEY);
	tecla |= FLAG_TECLA_PULSADA;
	piUnlock(KEYBOARD_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	g_tecladoSharedVars.debounceTime = millis() + DEBOUNCE_TIME_MS;
}

void teclado_fila_4_isr(void) {
	if (millis() < g_tecladoSharedVars.debounceTime) {
		g_tecladoSharedVars.debounceTime = millis() + DEBOUNCE_TIME_MS;
		return;
	}

	char tecla = g_tecladoSharedVars.teclaDetectada;

	piLock(KEYBOARD_KEY);
	tecla |= FLAG_TECLA_PULSADA;
	piUnlock(KEYBOARD_KEY);

	piLock(STD_IO_LCD_BUFFER_KEY);
	printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
	fflush(stdout);
	piUnlock(STD_IO_LCD_BUFFER_KEY);

	g_tecladoSharedVars.debounceTime = millis() + DEBOUNCE_TIME_MS;
}

void timer_duracion_columna_isr(union sigval value) {
	// Simplemente avisa que ha pasado el tiempo para excitar la siguiente columna
	piLock(KEYBOARD_KEY);
	g_tecladoSharedVars.flags |= FLAG_TIMEOUT_COLUMNA_TECLADO;
	piUnlock(KEYBOARD_KEY);
}
