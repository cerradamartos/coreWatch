#include "teclado_TL04.h"

const char tecladoTL04[NUM_FILAS_TECLADO][NUM_COLUMNAS_TECLADO] = {
		{'1', '2', '3', 'C'},
		{'4', '5', '6', 'D'},
		{'7', '8', '9', 'E'},
		{'A', '0', 'B', 'F'}
};

// Maquina de estados: lista de transiciones
// {EstadoOrigen, CondicionDeDisparo, EstadoFinal, AccionesSiTransicion }
fsm_trans_t g_fsmTransExcitacionColumnas[] = {
		{ TECLADO_ESPERA_COLUMNA, CompruebaTimeoutColumna, TECLADO_ESPERA_COLUMNA, TecladoExcitaColumna },
		{-1, NULL, -1, NULL },
};

static TipoTecladoShared g_tecladoSharedVars;

//------------------------------------------------------
// FUCNIONES DE INICIALIZACION DE LAS VARIABLES ESPECIFICAS
//------------------------------------------------------
void ConfiguraInicializaTeclado(TipoTeclado *p_teclado) {

	// A completar por el alumno...

	// Inicializacion de elementos de la variable global de tipo TipoTecladoShared:
	// 1. Valores iniciales de todos los "debounceTime"
	// 2. Valores iniciales de todos "columnaActual", "teclaDetectada" y "flags"

		int i;

		for (i = 0; i < NUM_FILAS_TECLADO; i++) {
			piLock(KEYBOARD_KEY);
			g_tecladoSharedVars.debounceTime[i] = 0;
			piUnlock(KEYBOARD_KEY);

		}

		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.columnaActual = 1;	//Inicializamos a columna 1
		g_tecladoSharedVars.teclaDetectada = 'h';//Inicializamos el valor de la tecla pulsada
		piUnlock(KEYBOARD_KEY);

		//g_tecladoSharedVars.columnaActual = COLUMNA_1;

		g_tecladoSharedVars.flags = 0;

		// Inicializacion de elementos de la estructura TipoTeclado:
		// Inicializacion del HW:
		// 1. Configura GPIOs de las columnas:
		// 	  (i) Configura los pines y (ii) da valores a la salida
		// 2. Configura GPIOs de las filas:
		// 	  (i) Configura los pines y (ii) asigna ISRs (y su polaridad)
		//
		pinMode(GPIO_KEYBOARD_COL_1, OUTPUT);//Se declaran las PIN de Columnas como salidas
		pinMode(GPIO_KEYBOARD_COL_2, OUTPUT);
		pinMode(GPIO_KEYBOARD_COL_3, OUTPUT);
		pinMode(GPIO_KEYBOARD_COL_4, OUTPUT);
		digitalWrite(GPIO_KEYBOARD_COL_1, LOW); //Da valores a la salida
		digitalWrite(GPIO_KEYBOARD_COL_2, LOW);
		digitalWrite(GPIO_KEYBOARD_COL_3, LOW);
		digitalWrite(GPIO_KEYBOARD_COL_4, LOW);

		pinMode(GPIO_KEYBOARD_ROW_1, INPUT);//Se declaran las PIN de Filas como entradas
		pinMode(GPIO_KEYBOARD_ROW_2, INPUT);
		pinMode(GPIO_KEYBOARD_ROW_3, INPUT);
		pinMode(GPIO_KEYBOARD_ROW_4, INPUT);
		pullUpDnControl(GPIO_KEYBOARD_ROW_1, PUD_DOWN);
		pullUpDnControl(GPIO_KEYBOARD_ROW_2, PUD_DOWN);
		pullUpDnControl(GPIO_KEYBOARD_ROW_3, PUD_DOWN);
		pullUpDnControl(GPIO_KEYBOARD_ROW_4, PUD_DOWN);

		wiringPiISR(GPIO_KEYBOARD_ROW_1, INT_EDGE_RISING, teclado_fila_1_isr); //Asigna ISR�s y su polaridad
		wiringPiISR(GPIO_KEYBOARD_ROW_2, INT_EDGE_RISING, teclado_fila_2_isr);
		wiringPiISR(GPIO_KEYBOARD_ROW_3, INT_EDGE_RISING, teclado_fila_3_isr);
		wiringPiISR(GPIO_KEYBOARD_ROW_4, INT_EDGE_RISING, teclado_fila_4_isr);

		//Inicializamos  el wiringPi
		// Inicializacion del temporizador:
		// 3. Crear y asignar temporizador de excitacion de columnas
		// 4. Lanzar temporizador

		p_teclado->tmr_duracion_columna = tmr_new(timer_duracion_columna_isr);

		tmr_init(p_teclado->tmr_duracion_columna, timer_duracion_columna_isr);



}

//------------------------------------------------------
// FUNCIONES PROPIAS
//------------------------------------------------------
/* Getter y setters de variables globales */

TipoTecladoShared GetTecladoSharedVar() {
	TipoTecladoShared result;

	piLock (KEYBOARD_KEY);
	result = g_tecladoSharedVars;
	piUnlock (KEYBOARD_KEY);

	return result;

}
void SetTecladoSharedVar(TipoTecladoShared value) {

	piLock (KEYBOARD_KEY);
	g_tecladoSharedVars = value;
	piUnlock (KEYBOARD_KEY);
}

void ActualizaExcitacionTecladoGPIO(int columna) {
	// ATENCION: Evitar que este mas de una columna activa a la vez.

	// A completar por el alumno
	// ...
	switch(columna){
	// ...
	case COLUMNA_1:
		digitalWrite(GPIO_KEYBOARD_COL_1,HIGH);
		digitalWrite(GPIO_KEYBOARD_COL_2,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_3,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_4,LOW);
		break;
	case COLUMNA_2:
		digitalWrite(GPIO_KEYBOARD_COL_1,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_2,HIGH);
		digitalWrite(GPIO_KEYBOARD_COL_3,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_4,LOW);
		break;

	case COLUMNA_3:
		digitalWrite(GPIO_KEYBOARD_COL_1,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_2,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_3,HIGH);
		digitalWrite(GPIO_KEYBOARD_COL_4,LOW);
		break;

	case COLUMNA_4:
		digitalWrite(GPIO_KEYBOARD_COL_1,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_2,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_3,LOW);
		digitalWrite(GPIO_KEYBOARD_COL_4,HIGH);
		break;
	default:
		break;
	}

}

//------------------------------------------------------
// FUNCIONES DE ENTRADA O DE TRANSICION DE LA MAQUINA DE ESTADOS
//------------------------------------------------------
int CompruebaTimeoutColumna(fsm_t* p_this) {
	int result = 0;

	piLock(KEYBOARD_KEY);
	result = g_tecladoSharedVars.flags & FLAG_TIMEOUT_COLUMNA_TECLADO;	//Comprueba si se ha activado el flag
	piUnlock(KEYBOARD_KEY);

	return result;
}


//------------------------------------------------------
// FUNCIONES DE SALIDA O DE ACCION DE LAS MAQUINAS DE ESTADOS
//------------------------------------------------------
void TecladoExcitaColumna(fsm_t* p_this) {
	TipoTeclado *p_teclado = (TipoTeclado*)(p_this->user_data);

	// 1. Actualizo que columna SE VA a excitar
	// 2. Ha pasado el timer y es hora de excitar la siguiente columna:
	//    (i) Llamada a ActualizaExcitacionTecladoGPIO con columna A ACTIVAR como argumento
	// 3. Actualizar la variable flags
	// 4. Manejar el temporizador para que vuelva a avisarnos

	//Inicializamos a nivel low todas las columnas
	digitalWrite(GPIO_KEYBOARD_COL_1,LOW);
	digitalWrite(GPIO_KEYBOARD_COL_2,LOW);
	digitalWrite(GPIO_KEYBOARD_COL_3,LOW);
	digitalWrite(GPIO_KEYBOARD_COL_4,LOW);

	piLock(KEYBOARD_KEY);
	g_tecladoSharedVars.columnaActual++;//Aumentamos col actual
	piUnlock(KEYBOARD_KEY);

	//Reiniciamos si ya hemos llegado a �ltima columna y excitamos columna 0, si no, excitamos columna actual
	if(g_tecladoSharedVars.columnaActual > 3){
		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.columnaActual = 0;
		piUnlock(KEYBOARD_KEY);

		piLock(KEYBOARD_KEY);
		ActualizaExcitacionTecladoGPIO(g_tecladoSharedVars.columnaActual);
		piUnlock(KEYBOARD_KEY);

	}else{
		piLock(KEYBOARD_KEY);
		ActualizaExcitacionTecladoGPIO(g_tecladoSharedVars.columnaActual);
		piUnlock(KEYBOARD_KEY);
	}

//	p_teclado->columnas = gpio_col[g_tecladoSharedVars.columnaActual];
//	ActualizaExcitacionTecladoGPIO(p_teclado->columnas);

	piLock(KEYBOARD_KEY);
	g_tecladoSharedVars.flags &= ~FLAG_TIMEOUT_COLUMNA_TECLADO;//Limpia el flag
	piUnlock(KEYBOARD_KEY);

	tmr_startms(p_teclado->tmr_duracion_columna, TIMEOUT_COLUMNA_TECLADO_MS);
}

//------------------------------------------------------
// SUBRUTINAS DE ATENCION A LAS INTERRUPCIONES
//------------------------------------------------------
void teclado_fila_1_isr(void) {
	// 1. Comprobar si ha pasado el tiempo de guarda de anti-rebotes
	// 2. Atender a la interrupcion:
	// 	  (i) Guardar la tecla detectada en g_tecladoSharedVars
	//    (ii) Activar flag para avisar de que hay una tecla pulsada
	// 3. Actualizar el tiempo de guarda del anti-rebotes

	if(millis () < g_tecladoSharedVars.debounceTime[0]){
//		piLock(KEYBOARD_KEY);
//		g_tecladoSharedVars.debounceTime[0] = millis () + DEBOUNCE_TIME_MS;//debounceTime es un array
//		piUnlock(KEYBOARD_KEY);

		return;
	}

//	while(digitalRead(GPIO_KEYBOARD_ROW_1) == HIGH){
//		delay(1);
//	}

//	g_tecladoSharedVars.teclaDetectada = tecladoTL04[0][g_tecladoSharedVars.columnaActual];
//	char tecla = g_tecladoSharedVars.teclaDetectada;

	piLock(KEYBOARD_KEY);
	g_tecladoSharedVars.teclaDetectada = tecladoTL04[FILA_1][g_tecladoSharedVars.columnaActual];
	g_tecladoSharedVars.flags |= FLAG_TECLA_PULSADA;
	piUnlock(KEYBOARD_KEY);

//	piLock(STD_IO_LCD_BUFFER_KEY);
//	printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
//	fflush(stdout);
//	piUnlock(STD_IO_LCD_BUFFER_KEY);

	piLock(KEYBOARD_KEY);
	g_tecladoSharedVars.debounceTime[0] = millis () + DEBOUNCE_TIME_MS;
	piUnlock(KEYBOARD_KEY);
}

void teclado_fila_2_isr(void) {
	if(millis () < g_tecladoSharedVars.debounceTime[1]){
//			piLock(KEYBOARD_KEY);
//			g_tecladoSharedVars.debounceTime[1] = millis () + DEBOUNCE_TIME_MS;//debounceTime es un array
//			piUnlock(KEYBOARD_KEY);

			return;
		}

//		while(digitalRead(GPIO_KEYBOARD_ROW_2) == HIGH){
//			delay(1);
//		}
//
//		g_tecladoSharedVars.teclaDetectada = tecladoTL04[1][g_tecladoSharedVars.columnaActual];
//		char tecla = g_tecladoSharedVars.teclaDetectada;

		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.teclaDetectada = tecladoTL04[FILA_2][g_tecladoSharedVars.columnaActual];
		g_tecladoSharedVars.flags |= FLAG_TECLA_PULSADA;
		piUnlock(KEYBOARD_KEY);

//		piLock(STD_IO_LCD_BUFFER_KEY);
//		printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
//		fflush(stdout);
//		piUnlock(STD_IO_LCD_BUFFER_KEY);

		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.debounceTime[1] = millis () + DEBOUNCE_TIME_MS;
		piUnlock(KEYBOARD_KEY);
}

void teclado_fila_3_isr(void) {
	if(millis () < g_tecladoSharedVars.debounceTime[2]){
//			piLock(KEYBOARD_KEY);
//			g_tecladoSharedVars.debounceTime[2] = millis () + DEBOUNCE_TIME_MS;//debounceTime es un array
//			piUnlock(KEYBOARD_KEY);

			return;
		}

//		while(digitalRead(GPIO_KEYBOARD_ROW_3) == HIGH){
//			delay(1);
//		}
//
//		g_tecladoSharedVars.teclaDetectada = tecladoTL04[2][g_tecladoSharedVars.columnaActual];
//		char tecla = g_tecladoSharedVars.teclaDetectada;

		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.teclaDetectada = tecladoTL04[FILA_3][g_tecladoSharedVars.columnaActual];
		g_tecladoSharedVars.flags |= FLAG_TECLA_PULSADA;
		piUnlock(KEYBOARD_KEY);

//		piLock(STD_IO_LCD_BUFFER_KEY);
//		printf("Una tecla ha sido pulsada\n"); // Informo al usuario del valor de tempTime
//		fflush(stdout);
//		piUnlock(STD_IO_LCD_BUFFER_KEY);

		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.debounceTime[2] = millis () + DEBOUNCE_TIME_MS;
		piUnlock(KEYBOARD_KEY);
}

void teclado_fila_4_isr(void) {
	if(millis () < g_tecladoSharedVars.debounceTime[3]){
//			piLock(KEYBOARD_KEY);
//			g_tecladoSharedVars.debounceTime[3] = millis () + DEBOUNCE_TIME_MS;//debounceTime es un array
//			piUnlock(KEYBOARD_KEY);

			return;
		}

//		while(digitalRead(GPIO_KEYBOARD_ROW_4) == HIGH){
//			delay(1);
//		}
//
//		g_tecladoSharedVars.teclaDetectada = tecladoTL04[3][g_tecladoSharedVars.columnaActual];
//		char tecla = g_tecladoSharedVars.teclaDetectada;

		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.teclaDetectada = tecladoTL04[FILA_4][g_tecladoSharedVars.columnaActual];
		g_tecladoSharedVars.flags |= FLAG_TECLA_PULSADA;
		piUnlock(KEYBOARD_KEY);

//
		piLock(KEYBOARD_KEY);
		g_tecladoSharedVars.debounceTime[3] = millis () + DEBOUNCE_TIME_MS;
		piUnlock(KEYBOARD_KEY);
}

void timer_duracion_columna_isr(union sigval value) {
	// Simplemente avisa que ha pasado el tiempo para excitar la siguiente columna
	piLock(KEYBOARD_KEY);
	g_tecladoSharedVars.flags |= FLAG_TIMEOUT_COLUMNA_TECLADO;//Activa el flag
	piUnlock(KEYBOARD_KEY);
}
